# Handoff: OSINT Live Globe — DeltaSweep-style UI redesign

## Overview
A redesign of the OSINT Live Globe frontend (`frontend/src/`, React + Vite + Leaflet) that keeps OSINT's icon-first design language (the `svgIcons.js` glyph vocabulary, cyan HUD palette, severity/reliability chips) while adopting DeltaSweep-style ergonomics: layer controls as top-bar category pills with dropdowns, time-range pills + Play replay, a persistent search bar, a toggleable left intel feed with a watchlist, a bottom HUD status strip, stackable board panels, and dark + light themes.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate these designs inside the existing OSINT codebase** (React + Vite + Leaflet, `frontend/src/`) using its established patterns: components under `src/components/`, map logic through `createMapController.js` / `useLeafletMap`, settings through `useAppSettings`, CSS custom properties in `style.css`, motion tokens from `motion.css`. Do not ship the HTML.

Both prototypes deliberately import the real `frontend/src/map/svgIcons.js` (copied here as `assets/svgIcons.js`) — every marker and legend glyph is the production glyph, so no icon work is needed.

## Fidelity
**High-fidelity.** Colors, typography, spacing, chip styles, and layout are final. Recreate pixel-perfectly, mapping values onto the existing CSS custom-property system (most tokens already exist in `style.css`; new ones are listed under Design Tokens).

## Screens / Views

### 1. Boot / loading screen (`osint-redesign.html` — `#boot`)
- **Purpose**: covers the map until each boot source resolves once (same contract as the existing `LoadingScreen.jsx`).
- **Layout**: fullscreen overlay, `radial-gradient(ellipse at center, #071822 0%, #000308 75%)`, centered column max-width 400px, gap 18px. Always dark, theme-independent (existing behavior, kept).
- **Components**: wireframe globe SVG (rim stroke `rgba(111,227,255,0.4)`, lines `0.22`); wordmark `OSINT LIVE GLOBE` mono 700 19px letter-spacing 6px `#6fe3ff`; subtitle mono 9px letter-spacing 2.5px uppercase `#7f96a6`; 12-row source log (mono 10.5px, pending `⋯` dim 0.5 opacity → ok `✓` `#34c759` with right-aligned record counts, tabular-nums); 2px progress bar fill `#6fe3ff`.
- **Behavior**: rows resolve sequentially (~130ms stagger in the mock; real app drives from source status), overlay fades out 0.7s ease-out when done. Reuse `MIN_VISIBLE_MS`/`MAX_VISIBLE_MS`/timeout-relabel logic from the existing `LoadingScreen.jsx`.

### 2. Main map view (`osint-redesign.html`)
Chrome regions, top to bottom:

**Top bar `#topBar`** — fixed, height 44px, z 1200, `--bar-bg` + 1px bottom border `--panel-border`, backdrop-blur 8px, padding 0 12px, flex gap 8px.
- Brand: `OSINT LIVE GLOBE` mono 700 13px letter-spacing 2.5px in `--accent`; `LIVE` badge (mono 9px ls 1.5px, green `#34c759`, 1px border `rgba(52,199,89,0.45)`, radius 3px, 6px pulsing dot, 2.4s ease-in-out).
- **Category pills** (one per layer group — Conflict `#ff3b30`, Traffic `#35c2ff`, Infra `#ff9500`, Airspace `#ff8c00`, Hazards `#ffb347`, Space `#6fe3ff`, plus a red-tinted Reset): mono 9.5px uppercase ls 1px, padding 4px 7px, radius 4px, `--control-bg` fill, 1px `--panel-border`; 7px colored dot; active-count badge (9px, radius 8px, `rgba(accent,0.16)` fill, accent text). Hover: accent border + bright text. Open state: accent border + `rgba(accent,0.10)` fill.
- Pill dropdown: absolute below (+8px), min-width 270px, `--panel-bg`, radius 6px, shadow `0 8px 26px`, 0.14s drop-in (translateY −5px→0). Header row: mono 9px ls 1.6px dim, "<Group> layers / n active". Layer rows: checkbox (accent `accent-color`), 14px glyph from `svgIcons.js` tinted with the layer's palette token color, 11.5px label, right-aligned mono count; sub-rows indented 22px; `inferred` dashed tag preserved (from existing `.inferred-tag`). Toggling updates the map layer group and the HUD "Layers" count.
- Right cluster (flex none): stat blocks (value mono 700 13px — Aircraft/Vessels in accent, Events in `--danger`; label mono 8px ls 1.2px dim uppercase), UTC clock (mono 700 13px + `ZULU` 8px), theme toggle icon button 26×26 radius 4px.
- Responsive: <1330px hide count badges; <1150px hide Aircraft/Vessels stats; <1080px pills collapse to dot-only.

**Sub bar `#subBar`** — fixed at top 44px, height 34px, same surface.
- `☰ FEED` ghost button toggles the feed panel (map shifts left edge 0↔332px, 0.23s ease-out, then `map.invalidateSize()`).
- Time pills `1H 6H 24H 48H 7D 30D ALL`: joined group inside one 1px border radius 4px; each mono 10px ls 1px padding 5px 9px; active = accent fill, `--accent-ink` text, 700.
- `▶ PLAY` button: green outline `rgba(52,199,89,0.5)`, mono 10px ls 1.4px; playing state swaps to `❚❚ PAUSE` + `rgba(52,199,89,0.16)` fill.
- Persistent search: flex 0 1 340px, radius 4px, `--control-bg`, 11.5px, `◎` glyph left inset 8px; focus border accent.
- Right: ghost buttons Boards ▾ / Copy link / Export / Admin (mono 9.5px ls 1.2px uppercase; Admin active state = `--warn` fill like existing `#adminToggle.active`).
- **Boards dropdown**: same dropdown pattern as pills, right-aligned; one row per board with glyph + ✓ when open.

**Feed panel `#feed`** — fixed left, width 332px, from y 78 to bottom 34, `--panel-bg` + right border, slides in/out (translateX), open by default.
- Watchlist section: header mono 9.5px ls 1.8px dim uppercase "📌 WATCHLIST n" + accent `＋` button; empty state 10.5px dim; items = 13px glyph + 11px name + `✕`. Max-height 150px, scrolls. Items added via popup "📌 Watchlist" button or `＋`.
- Tabs: Activity / Events / News / Officials / Sanctions — mono 9px ls 1.2px uppercase, 2px bottom-border indicator in accent (same pattern as existing `.intel-tab`).
- Filter chip row (Activity + Events only): ALL / STRIKE / AIR / NAVAL / GND / EXPL — mono 8.5px uppercase, 10px glyph, radius 3px; active = accent border + `rgba(accent,0.16)` fill. Filters the list by event category.
- Feed items: padding 8px 12px, 1px hairline `rgba(accent,0.12)`, hover `rgba(accent,0.06)`. Row 1: severity chip + reliability chip + 13px type glyph. Row 2: title 11.5px/1.35 (dim suffix for caveats like "weakly placed"). Row 3: mono 9.5px dim meta (source · age) + 20px circular locate button (flies map to the record, existing `flyTo` behavior). "Breaking" kicker: mono 8.5px 700 red, 1.6s pulse.
- Chips: severity uses the existing severity band colors (below); reliability Reliable `#34c759` / Mixed `#e0a52c` / Weak `#b8722c`; text `#0b0d10` mono 8px 700 uppercase, radius 2px, padding 2px 5px. Severity and reliability remain **two separate chips** (separate axes — preserve this).

**Legend `#legend`** — fixed top-right over map, width 250px, collapsed by default. Header: mono 9.5px ls 1.8px uppercase with a 3px×12px accent tick bar before the text; caret rotates −90° collapsed. Body: 2-column grid of 12px glyph + 10px label pairs.

**Board stack `#boardStack`** — fixed right 12px, bottom 44px, width 288px, column-reverse, gap 8px. Boards: Chokepoints (default open), Airfield activity, Infrastructure risk, Cable outages. Each: header (same accent-tick style, mono 9px, accent count, `✕`), scrollable body max 200px; rows = 12px glyph + 10.5px name + right mono 9px metric with trend mark (▲ `--danger`, ▼/✓ `--ok`, — dim). Header click collapses; ✕ closes. Data sources map to the existing `ChokepointPanel`, `AirfieldActivityPanel`, `InfraRiskPanel`, `CableOutagePanel` logic modules.

**Replay scrub strip `#scrubStrip`** — fixed above HUD, height 34px, hidden until Play/scrub. Mono 10px accent timestamp label (min-width 120px), full-width range slider (accent), `● LIVE` pill button returns to live and hides the strip. Play advances the scrubber ~0.6%/80ms in the mock; wire to the existing `useReplay` cadence/step settings.

**Bottom HUD `#hud`** — fixed bottom, height 34px, `--bar-bg`, top border, mono throughout. Cells divided by 1px `rgba(accent,0.14)` rules, padding 0 13px; label 8px ls 1.4px dim uppercase + value 12px 700 tabular-nums.
- Escalation: 110×5px gradient bar (`#34c759→#e0a52c→#ff5c2a→#ff1a1a`) with 2px white position needle + red numeric value.
- GPS Jam % (`--warn`), Events (accent, mirrors filter), Layers (count of checked layer rows), Latency, Sources (five 6px status dots + "11/12"), Cursor coords (right-aligned cell, accent, live `mousemove` → `26.000°N 30.000°E` format, 3 decimals).

**Map**: Leaflet, CARTO `dark_all` basemap (existing default; `light_all` in light theme). Zoom control **bottom-left** (bottom-right collides with the board stack). Markers use existing `buildDivIcon`-style div icons: `.entity-icon-wrap` drop-shadow halo, military red glow, navy yellow glow, tanker amber glow, dashed `imprecise` ring — all unchanged from production CSS.

**Popups** — restyled Leaflet popups, width 280px, radius 6px, `--popup-bg`, accent-tinted border `rgba(accent,0.35)`.
- Header block (bottom hairline): kicker (mono 8.5px ls 1.8px uppercase dim, 3px accent tick before) naming record kind + provenance ("CONFLICT EVENT · ACLED+GDELT", "VESSEL · AIS", "AIRSPACE BULLETIN · EASA CZIB"); title 13.5px 700.
- Body: 2-column key/value grid (keys mono 8.5px ls 1.2px uppercase dim; values 11px right-aligned tabular); severity/reliability chip row; caveat note 10.5px `--text-secondary` (provenance caveats verbatim — "single outlet", "weakly placed", "coded fields only" — never dropped); action row: `📌 Watchlist` (accent tint primary), `Details`, `Source ↗` (mono 8.5px outline buttons). Watchlist click → adds item, button becomes `✓ Pinned` disabled.

### 3. Current-UI recreation (`osint-current.html`)
Reference only — a faithful copy of today's UI built from `frontend/src/style.css` values, for side-by-side comparison during implementation. Not to be built.

## Interactions & Behavior
- Category pill: click opens its dropdown (one open at a time; outside click closes). Checkbox change toggles that layer on the map immediately and updates HUD layer count. Reset re-checks everything.
- Feed toggle: 0.23s ease-out slide; map `invalidateSize()` after 240ms (existing pattern).
- Feed item click / locate: `map.flyTo(latlng, 6, {duration:1.2})`.
- Tabs switch list content; chip filters apply within Activity/Events.
- Time pills: single-select; should drive the event age window (`eventFilter.maxAgeDays` — the one shared filter object in `App.jsx`).
- Play: shows scrub strip, animates from 0→100 (−3d→live), pauses on second click; Go-live resets and hides. Scrubbing must gate live poller writes exactly as `useReplay` does today.
- Theme toggle: flips `data-theme` on `<html>`, swaps CARTO dark_all/light_all, icon ☀/☾. All colors flow from the custom properties — no per-component theme code.
- Watchlist: session state in the mock; persist per the app's existing localStorage panel-state conventions.
- Boards: open set toggled from Boards menu; collapse per-board; close with ✕.
- Reduce-motion: all pulses/loops must respect the existing `:root.reduce-motion` and `prefers-reduced-motion` kill-list convention in `style.css`.

## State Management
- `openCategory: string|null` (pill dropdowns), `layerChecks` (feeds existing `layerWishes`/`onToggleLayer` — keep the resolver/pinned tri-state semantics from `LayerCheck.jsx`; the mock simplifies to plain checkboxes).
- `feedOpen: bool`, `activeTab`, `chipFilter`, `watchlist: []`.
- `timeWindow` (pills) → shared `eventFilter`.
- `replay {isReplaying, isPlaying, replayAt}` → existing `useReplay`.
- `openBoards: Set`, per-board collapsed.
- `theme` → existing `useTheme`.
- HUD values derive from existing sources: counts from layer payloads, latency/sources from `useHealth`, escalation from `backend/escalation.py` ranking, jam % from the jamming layer.

## Design Tokens
Dark (default) / Light (`[data-theme="light"]`):
- `--bg-page` #000308 / #eef3f6 · `--bg-map` #060d14 / #dbe4ea
- `--text-primary` #d7e2ea / #1b2733 · `--text-secondary` #9fb2c0 / #46586a · `--text-dim` #7f96a6 / #5c7383 · `--text-bright` #eaf6ff / #0c141c
- `--accent` #6fe3ff / #0089ad (`--accent-rgb` 111,227,255 / 0,137,173) · `--accent-ink` #001018 / #ffffff
- `--panel-bg` rgba(6,14,22,.94) / rgba(255,255,255,.95) · `--panel-border` rgba(accent,.25/.28)
- `--bar-bg` rgba(3,9,15,.92) / rgba(255,255,255,.94) · `--control-bg` rgba(6,14,22,.85) / rgba(255,255,255,.9) · `--popup-bg` rgba(6,14,22,.96) / rgba(255,255,255,.97)
- Status: `--danger` #ff3d3d · `--warn` #ff8c3a · `--ok` #34c759
- Severity (unchanged from `iconTheme.js`): critical #ff1a1a · high #e03131 · moderate #b02525 · low #7f1d1d · corroborated #3ac1ff · UCDP record #8f9bb3
- Reliability: Reliable #34c759 · Mixed #e0a52c · Weak #b8722c
- Fonts: body `"Segoe UI", Consolas, monospace`; HUD labels `--mono: Consolas, "SF Mono", "Cascadia Mono", monospace`, always uppercase + tracked (1–2.5px).
- Radii: bars/pills/buttons 4px, panels/popups 6px. Blur: backdrop-filter 8px on fixed chrome. Shadows: dropdowns/panels `0 8px 26px` / `0 6px 20px` in `--shadow`.
- Marker colors: use the existing `PALETTE_GROUPS` tokens in `frontend/src/map/iconTheme.js` verbatim (navy #ffd60a, tanker #ffb347, civilian ship #35c2ff, military aircraft #ff4d4d, commercial #d8b9ff, news #ffd60a, diplomacy #7ee0c9, infra per-type, cables #4fd1c5, jamming #e066ff, CZIB #ff8c00, satellites #6fe3ff…).

## Assets
- `assets/svgIcons.js` — verbatim copy of `frontend/src/map/svgIcons.js`; the single icon source. All glyphs are 24×24 currentColor SVG inner-markup strings.
- Basemap tiles: CARTO `dark_all` / `light_all` (already the app's basemaps).
- No raster assets.

## Files
- `osint-redesign.html` — the redesign prototype (all screens/behaviors above). Primary reference.
- `osint-current.html` — recreation of today's UI, for comparison.
- `assets/svgIcons.js` — icon module both pages import.
- All mock data (events, vessels, aircraft, boards, feeds) is inline in each HTML file's single `<script type="module">`.
